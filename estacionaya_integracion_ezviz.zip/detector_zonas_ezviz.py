
import json
import os
import threading
import time

import cv2
import numpy as np
import win32gui

from ultralytics import YOLO
from windows_capture import WindowsCapture


# ==========================================
# CONFIGURACION ESTACIONAYA
# ==========================================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

ARCHIVO_ZONAS = os.path.join(
    BASE_DIR,
    "zonas_ezviz_antizana.json"
)

MODELO_YOLO = "yolov8s.pt"

FRAMES_CONFIRMACION = 10
UMBRAL_SUPERPOSICION = 0.12
CONFIANZA_YOLO = 0.25

# COCO: carro, moto, autobus y camion
CLASES_VEHICULOS = [2, 3, 5, 7]

TITULO_EZVIZ = "ezviz studio"
TITULO_VENTANA = "EstacionaYa - Ocupacion por zonas"

ultimo_frame = None
bloqueo = threading.Lock()


# ==========================================
# BUSCAR VENTANA EZVIZ
# ==========================================

def buscar_ezviz():
    encontrados = []

    def callback(hwnd, _):
        if not win32gui.IsWindowVisible(hwnd):
            return

        titulo = win32gui.GetWindowText(hwnd)

        if titulo.strip().lower() == TITULO_EZVIZ:
            encontrados.append(hwnd)

    win32gui.EnumWindows(callback, None)

    return encontrados[0] if encontrados else None


# ==========================================
# CALCULAR SUPERPOSICION
# ==========================================

def calcular_superposicion(caja, roi):

    x1, y1, x2, y2 = caja
    x, y, w, h = roi

    inter_x1 = max(x1, x)
    inter_y1 = max(y1, y)

    inter_x2 = min(x2, x + w)
    inter_y2 = min(y2, y + h)

    ancho = max(0, inter_x2 - inter_x1)
    alto = max(0, inter_y2 - inter_y1)

    area_interseccion = ancho * alto
    area_zona = w * h

    if area_zona <= 0:
        return 0.0

    return area_interseccion / area_zona


# ==========================================
# CARGAR CONFIGURACION
# ==========================================

def cargar_zonas():

    if not os.path.exists(ARCHIVO_ZONAS):
        raise FileNotFoundError(
            f"No existe el archivo: {ARCHIVO_ZONAS}"
        )

    with open(
        ARCHIVO_ZONAS,
        "r",
        encoding="utf-8"
    ) as archivo:
        configuracion = json.load(archivo)

    ancho, alto = configuracion["frame_size"]
    zonas = configuracion["zones"]

    print("================================")
    print("CONFIGURACION DE ESTACIONAYA")
    print("================================")
    print(f"Resolucion: {ancho} x {alto}")
    print(f"Total de zonas: {len(zonas)}")

    for zona in zonas:
        print(f" - {zona['id']}: {zona['name']}")

    return ancho, alto, zonas


# ==========================================
# PROGRAMA PRINCIPAL
# ==========================================

def iniciar():

    global ultimo_frame

    print("===================================")
    print(" ESTACIONAYA - YOLO + EZVIZ")
    print("===================================")

    ancho_esperado, alto_esperado, zonas = cargar_zonas()

    hwnd = buscar_ezviz()

    if hwnd is None:
        print("ERROR: No se encontro EZVIZ Studio.")
        print("Abre EZVIZ PC Studio e intenta nuevamente.")
        return

    print("Ventana EZVIZ encontrada:", hwnd)

    if win32gui.IsIconic(hwnd):
        print("ERROR: Restaura la ventana de EZVIZ.")
        return

    print("Cargando YOLOv8...")
    modelo = YOLO(MODELO_YOLO)

    print("Iniciando captura directa...")

    captura = WindowsCapture(
        cursor_capture=False,
        draw_border=False,
        window_hwnd=hwnd
    )

    @captura.event
    def on_frame_arrived(frame, control):

        global ultimo_frame

        imagen = np.asarray(frame.frame_buffer)

        with bloqueo:
            ultimo_frame = imagen.copy()

    @captura.event
    def on_closed():
        print("Captura de EZVIZ finalizada.")

    control = captura.start_free_threaded()

    roi_video = None

    contadores = {
        zona["id"]: 0
        for zona in zonas
    }

    nombre = TITULO_VENTANA

    cv2.namedWindow(
        nombre,
        cv2.WINDOW_NORMAL
    )

    cv2.resizeWindow(
        nombre,
        900,
        500
    )

    print("-----------------------------------")
    print("Detector iniciado.")
    print("Selecciona el video EZVIZ.")
    print("Presiona Q para salir.")
    print("-----------------------------------")

    try:

        while True:

            # Obtener ultimo fotograma
            with bloqueo:
                imagen = (
                    ultimo_frame.copy()
                    if ultimo_frame is not None
                    else None
                )

            if imagen is None:
                time.sleep(0.03)

                if cv2.waitKey(30) & 0xFF == ord("q"):
                    break

                continue

            if imagen.ndim != 3:
                continue

            # Convertir formato de imagen
            if imagen.shape[2] == 4:
                imagen = cv2.cvtColor(
                    imagen,
                    cv2.COLOR_BGRA2BGR
                )

            # ==================================
            # SELECCIONAR EL VIDEO UNA SOLA VEZ
            # ==================================

            if roi_video is None:

                print("Selecciona SOLO el video ANTIZANA.")
                print("Presiona ESPACIO para confirmar.")

                roi_video = cv2.selectROI(
                    "Seleccionar video EZVIZ",
                    imagen,
                    showCrosshair=True,
                    fromCenter=False
                )

                cv2.destroyWindow(
                    "Seleccionar video EZVIZ"
                )

                if roi_video[2] <= 0 or roi_video[3] <= 0:
                    print("Seleccion cancelada.")
                    break

                print(
                    "Resolucion seleccionada:",
                    roi_video[2],
                    "x",
                    roi_video[3]
                )

                print(
                    "Resolucion de trabajo:",
                    ancho_esperado,
                    "x",
                    alto_esperado
                )

            # ==================================
            # RECORTAR VIDEO
            # ==================================

            x0, y0, w0, h0 = roi_video

            alto_imagen, ancho_imagen = imagen.shape[:2]

            if (
                x0 < 0
                or y0 < 0
                or x0 + w0 > ancho_imagen
                or y0 + h0 > alto_imagen
            ):
                print(
                    "ERROR: El video quedo fuera "
                    "de la region capturada."
                )
                break

            video = imagen[
                y0:y0 + h0,
                x0:x0 + w0
            ].copy()

            # ==================================
            # REDIMENSIONAMIENTO AUTOMATICO
            # ==================================

            if (
                video.shape[1] != ancho_esperado
                or video.shape[0] != alto_esperado
            ):

                video = cv2.resize(
                    video,
                    (ancho_esperado, alto_esperado),
                    interpolation=cv2.INTER_LINEAR
                )

            # ==================================
            # DETECCION CON YOLOv8
            # ==================================

            resultados = modelo.predict(
                source=video,
                imgsz=416,
                conf=CONFIANZA_YOLO,
                classes=CLASES_VEHICULOS,
                verbose=False
            )

            cajas = (
                resultados[0]
                .boxes.xyxy
                .cpu()
                .numpy()
            )

            vista = video.copy()

            # Dibujar detecciones YOLO
            for caja in cajas:

                x1, y1, x2, y2 = map(int, caja)

                cv2.rectangle(
                    vista,
                    (x1, y1),
                    (x2, y2),
                    (255, 150, 0),
                    2
                )

            # ==================================
            # ANALIZAR ZONAS
            # ==================================

            for zona in zonas:

                identificador = zona["id"]

                x, y, w, h = zona["roi"]

                detectado = any(
                    calcular_superposicion(
                        caja,
                        zona["roi"]
                    ) >= UMBRAL_SUPERPOSICION
                    for caja in cajas
                )

                # Confirmar ocupacion
                if detectado:

                    contadores[identificador] = min(
                        FRAMES_CONFIRMACION,
                        contadores[identificador] + 1
                    )

                else:

                    contadores[identificador] = max(
                        0,
                        contadores[identificador] - 1
                    )

                contador = contadores[identificador]

                # Determinar estado experimental
                if contador >= FRAMES_CONFIRMACION:

                    estado = "OCUPADO_PROBABLE"
                    color = (0, 0, 255)

                elif contador > 0:

                    estado = "VERIFICANDO"
                    color = (0, 255, 255)

                else:

                    estado = "SIN_DETECCION"
                    color = (255, 200, 0)

                # Dibujar estacionamiento
                cv2.rectangle(
                    vista,
                    (x, y),
                    (x + w, y + h),
                    color,
                    2
                )

                cv2.putText(
                    vista,
                    f"{identificador}: {estado}",
                    (x, max(20, y - 8)),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.45,
                    color,
                    1
                )

            # ==================================
            # MOSTRAR RESULTADO
            # ==================================

            cv2.imshow(
                nombre,
                vista
            )

            if cv2.waitKey(1) & 0xFF == ord("q"):
                print("Detector detenido.")
                break

    except KeyboardInterrupt:
        print("Programa interrumpido.")

    finally:
        control.stop()
        cv2.destroyAllWindows()

        print("Captura finalizada correctamente.")


if __name__ == "__main__":
    iniciar()
